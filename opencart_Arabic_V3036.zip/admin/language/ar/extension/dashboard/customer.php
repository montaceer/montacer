<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'عدد العملاء';

// Text
$_['text_extension']               = 'الموديولات';
$_['text_success']                 = 'تم التعديل !';
$_['text_edit']                    = 'تحرير';
$_['text_view'] = 'المزيد ...';

// Entry
$_['entry_status']                 = 'الحالة';
$_['entry_sort_order']             = 'ترتيب الفرز';
$_['entry_width']                  = 'العرض';

// Error
$_['error_permission']             = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
