<?php

// Heading
$_['heading_title'] = "Advertising";


// Columns
$_['column_name']   = "الاسم";
$_['column_status'] = "الحالة";
$_['column_action'] = "تحرير";


// Text
$_['text_success']   = "تم التعديل!";

// Error
$_['error_adblock'] = "It looks like you are using an ad blocker. In order to use this Advertising section, please disable your ad blocker for your OpenCart admin panel.";
