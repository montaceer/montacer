<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']  = 'الاضافات';

// Text
$_['text_success']   = 'تم التعديل !';
$_['text_list']      = 'قائمة';
$_['text_type']      = 'اختيار نوع الاضافة';
$_['text_filter']    = 'فلتر';
